


const vintageCarData = [
  {
    id: 1,
    brand: "Vintage Car",
    rating: 112,
    carName: "Luxury Cars Vintage Car Rental For Wedding",
    imgUrl: "https://blogs.gomechanic.com/wp-content/uploads/2019/08/1936_Packard_Custom_Convertible_Victoria_-_LeBaron_-_fvl-768x512.jpg",
    model: "Model 3",
    price: "25",
    speed: "20kmpl",
    gps: "GPS Navigation",
    seatType: "Heated seats",
    automatic: "Automatic",
    description:
      " Shaifali Traders, New Delhi, Delhi",
  },

  {
    id: 2,
    brand: "Vintage Car",
    rating: 102,
    carName: "Royal Vintage Car For Wedding",
    imgUrl: "https://5.imimg.com/data5/SELLER/Default/2024/4/413525823/QO/KR/ED/61385764/royal-vintage-car-for-wedding-500x500.jpeg",
    model: "Model-2022",
    price: 25,
    speed: "20kmpl",
    gps: "GPS Navigation",
    seatType: "Heated seats",
    automatic: "Automatic",
    description:
      "E4 Events & Promotion, New Delhi, Delhi",
  },

  {
    id: 3,
    brand: "Vintage Car",
    rating: 132,
    carName: "Royal Vintage Car On Rent",
    imgUrl: "https://5.imimg.com/data5/SELLER/Default/2024/8/441150061/TO/OO/LY/217662125/pfa-royal-vintage-car-pictures-on-rent-500x500.jpeg",
    model: "Model-2022",
    price: 65,
    speed: "20kmpl",
    gps: "GPS Navigation",
    seatType: "Heated seats",
    automatic: "Automatic",
    description:
      " Dolor labore lorem no accusam sit justo sadipscing labore invidunt voluptua, amet duo et gubergren vero gubergren dolor. At diam. Dolor labore lorem no accusam sit justo sadipscing labore invidunt voluptua, amet duo et gubergren vero gubergren dolor. At diam.",
  },

  {
    id: 4,
    brand: "Vintage Car",
    rating: 102,
    carName: "Nissan Mercielago",
    imgUrl: "https://5.imimg.com/data5/SELLER/Default/2021/9/EP/FZ/BA/21860276/open-vintage-car-rental-service-1000x1000.jpg",
    model: "Model-2022",
    price: 70,
    speed: "20kmpl",
    gps: "GPS Navigation",
    seatType: "Heated seats",
    automatic: "Automatic",
    description:
      " Dolor labore lorem no accusam sit justo sadipscing labore invidunt voluptua, amet duo et gubergren vero gubergren dolor. At diam. Dolor labore lorem no accusam sit justo sadipscing labore invidunt voluptua, amet duo et gubergren vero gubergren dolor. At diam.",
  },

];

export default vintageCarData;