package com.drivewise.car.customexception;

public class VintageCarNotFoundException extends RuntimeException {

	public VintageCarNotFoundException(String msg) {
		super(msg);
		
	}
}
